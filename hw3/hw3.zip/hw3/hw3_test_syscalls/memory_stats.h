long free_memory_stats(void);
long alloc_memory_stats(void);
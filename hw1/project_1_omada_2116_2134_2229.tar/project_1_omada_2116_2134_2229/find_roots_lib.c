#include "roots.h"

int main(int argc, char const *argv[])
{
	find_roots_wrapper();
	
	return (0);
}